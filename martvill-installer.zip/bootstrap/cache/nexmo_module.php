<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Nexmo\\Providers\\NexmoServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Nexmo\\Providers\\NexmoServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);