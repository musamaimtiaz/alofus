<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\GeoLocale\\Providers\\GeoLocaleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\GeoLocale\\Providers\\GeoLocaleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);