<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Fast2Sms\\Providers\\Fast2SmsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Fast2Sms\\Providers\\Fast2SmsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);