<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\GoogleAnalytics\\Providers\\GoogleAnalyticsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\GoogleAnalytics\\Providers\\GoogleAnalyticsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);