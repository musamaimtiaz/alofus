<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Flutterwave\\Providers\\FlutterwaveServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Flutterwave\\Providers\\FlutterwaveServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);