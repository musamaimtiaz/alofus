<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Abc\\Providers\\AbcServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Abc\\Providers\\AbcServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);