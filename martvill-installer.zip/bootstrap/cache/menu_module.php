<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Menu\\Providers\\MenuServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Menu\\Providers\\MenuServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);