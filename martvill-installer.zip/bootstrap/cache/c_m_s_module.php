<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CMS\\Providers\\CMSServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CMS\\Providers\\CMSServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);