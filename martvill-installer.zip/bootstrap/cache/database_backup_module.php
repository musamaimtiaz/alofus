<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DatabaseBackup\\Providers\\DatabaseBackupServiceProvider',
    1 => 'Modules\\DatabaseBackup\\Providers\\DropboxServiceProvider',
    2 => 'Modules\\DatabaseBackup\\Providers\\GoogleDriveServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DatabaseBackup\\Providers\\DatabaseBackupServiceProvider',
    1 => 'Modules\\DatabaseBackup\\Providers\\DropboxServiceProvider',
    2 => 'Modules\\DatabaseBackup\\Providers\\GoogleDriveServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);