<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\FormBuilder\\Providers\\FormBuilderServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\FormBuilder\\Providers\\FormBuilderServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);