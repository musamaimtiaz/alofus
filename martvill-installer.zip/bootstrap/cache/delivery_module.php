<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Delivery\\Providers\\DeliveryServiceProvider',
    1 => 'Modules\\Delivery\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Delivery\\Providers\\DeliveryServiceProvider',
    1 => 'Modules\\Delivery\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);