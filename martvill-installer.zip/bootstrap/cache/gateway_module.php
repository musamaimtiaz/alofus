<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Gateway\\Providers\\GatewayServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Gateway\\Providers\\GatewayServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);