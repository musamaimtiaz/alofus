<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\PageBuilder\\Providers\\PageBuilderServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\PageBuilder\\Providers\\PageBuilderServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);