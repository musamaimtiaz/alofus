<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\POS\\Providers\\POSServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\POS\\Providers\\POSServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);