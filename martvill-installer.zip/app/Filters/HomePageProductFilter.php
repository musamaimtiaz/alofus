<?php

namespace App\Filters;

class HomePageProductFilter extends Filter
{
}
