<?php

namespace App\Exceptions;

/**
 * InvalidCodeException.
 */
class EmailException extends \Exception
{
}
