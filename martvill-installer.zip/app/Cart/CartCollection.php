<?php
/**
 * @author TechVillage <support@techvill.org>
 *
 * @contributor Sakawat Hossain Rony <[sakawat.techvill@gmail.com]>
 *
 * @created 24-11-2021
 */

namespace App\Cart;

use Illuminate\Support\Collection;

class CartCollection extends Collection
{
}
