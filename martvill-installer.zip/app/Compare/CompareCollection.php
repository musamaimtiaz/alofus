<?php

namespace App\Compare;

use Illuminate\Support\Collection;

class CompareCollection extends Collection
{
}
